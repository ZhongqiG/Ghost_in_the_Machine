num_bits = 12; 
net_in_t = -3:0.5:3.5;
alpha_t = 1;

net_in = timeseries(net_in_t);
alpha = timeseries(alpha_t);