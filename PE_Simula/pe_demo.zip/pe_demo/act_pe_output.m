act_out = out.act_out.DATA(1:15).';
display(act_out);